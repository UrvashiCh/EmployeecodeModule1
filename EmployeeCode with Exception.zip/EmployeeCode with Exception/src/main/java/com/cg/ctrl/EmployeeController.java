package com.cg.ctrl;


import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.beans.EmployeeCode;
import com.cg.dao.EmployeeRepository;
import com.cg.exception.EMSNotFoundException;


@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(value="/employeecode")
public class EmployeeController 
{
	private static Logger log = LogManager.getLogger(EmployeeController.class);
	
	@Autowired
	EmployeeRepository repo;
	
	@GetMapping(value="/display/")
	public List<EmployeeCode> getAllEmployees() throws EMSNotFoundException
	{
		List<EmployeeCode> list = repo.findAll();
		log.info("Returning List of records");
		if(list.isEmpty())
		{
			log.error("No records found");
			throw new EMSNotFoundException("No Records in the Database");
		}
		
		return list;
	}
	
	@GetMapping(value="/find/{id}")
	public EmployeeCode findEmployeeById (@PathVariable("id") int id) throws EMSNotFoundException
	{
		EmployeeCode employee = repo.findById(id).get();
		log.info("Finding Employee By ID");
		if(employee==null)
		{
			log.error("Invalid Employee ID entered: "+id);
			throw new EMSNotFoundException("Invalid Employee ID: "+id);
		}
		return employee;
	}
	
	@PostMapping(value="/addEmployee",consumes=MediaType.APPLICATION_JSON_VALUE)
	public EmployeeCode add(@RequestBody EmployeeCode emp)
	{
		repo.save(emp);
		log.info("Employee Info Added Successfully");
		return emp;
	}
	
	@PutMapping(value="/modify")
	public int update(@RequestBody EmployeeCode emp) {
		repo.save(emp);
		log.info("Employee Info Updated of ID: "+emp.getEmpId());
		return 1;
	}
	
	
	@DeleteMapping(value="/delete/{unm}")
	public boolean deleteEmployee(@PathVariable("unm") int unm) throws EMSNotFoundException
	{
		System.out.println(unm);
		EmployeeCode employee = repo.findById(unm).get();
		log.info("Finding Employee By ID: "+unm);
		if(employee==null)
		{
			log.error("Invalid Employee ID entered "+unm);
			throw new EMSNotFoundException("Invalid Employee ID "+unm);
		}
		repo.deleteById(unm);
		log.info("Employee Deleted");
		return true;
	}
}
